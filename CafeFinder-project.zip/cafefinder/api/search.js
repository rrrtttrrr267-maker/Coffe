// Vercel Function: GET /api/search?city=Москва&cats=coffee,sushi (cats=all — все)
const FILTERS = {
  coffee: 'nwr(area.a)["name"]["amenity"="cafe"];',
  sushi: 'nwr(area.a)["name"]["cuisine"~"sushi|japanese",i];',
  restaurant: 'nwr(area.a)["name"]["amenity"="restaurant"];',
  pastry: 'nwr(area.a)["name"]["shop"~"pastry|confectionery",i];',
  pizza: 'nwr(area.a)["name"]["cuisine"~"pizza",i];',
  burger: 'nwr(area.a)["name"]["cuisine"~"burger",i];',
  bakery: 'nwr(area.a)["name"]["shop"="bakery"];',
  steak: 'nwr(area.a)["name"]["cuisine"~"steak",i];',
  cafe: 'nwr(area.a)["name"]["amenity"="cafe"];',
  asian: 'nwr(area.a)["name"]["cuisine"~"asian|chinese|thai|vietnamese|korean|noodle|ramen",i];'
};
const MIRRORS = [
  'https://overpass-api.de/api/interpreter',
  'https://overpass.kumi.systems/api/interpreter'
];
function classify(t) {
  const c = (t.cuisine || '').toLowerCase(), shop = (t.shop || '').toLowerCase();
  if (/sushi|japanese/.test(c)) return 'sushi';
  if (/pizza/.test(c)) return 'pizza';
  if (/burger/.test(c)) return 'burger';
  if (/steak/.test(c)) return 'steak';
  if (/asian|chinese|thai|vietnamese|korean|noodle|ramen/.test(c)) return 'asian';
  if (/pastry|confectionery/.test(shop)) return 'pastry';
  if (shop === 'bakery') return 'bakery';
  if (t.amenity === 'restaurant') return 'restaurant';
  if (t.amenity === 'cafe' && /coffee/.test(c)) return 'coffee';
  if (t.amenity === 'cafe') return 'cafe';
  return 'cafe';
}
module.exports = async (req, res) => {
  if (req.method !== 'GET') return res.status(405).json({error:'Method not allowed'});
  const city = String(req.query.city || '').trim();
  if (!/^[A-Za-zА-Яа-яЁё\s.\-]{2,60}$/.test(city))
    return res.status(400).json({error:'Некорректное название города'});
  let cats = String(req.query.cats || 'all').split(',').filter(c => Object.hasOwn(FILTERS,c));
  if (String(req.query.cats || 'all') === 'all' || !cats.length) cats = Object.keys(FILTERS);
  const clauses = cats.map(c => FILTERS[c]).join('\n');
  const q = `[out:json][timeout:45];
area["name"="${city}"]["boundary"="administrative"]["admin_level"~"4|5|6|7|8"]->.a;
(${clauses});
out center tags 600;`;
  let lastErr = 'Overpass недоступен';
  for (const endpoint of MIRRORS) {
    try {
      const r = await fetch(endpoint, {
        method:'POST', body:'data='+encodeURIComponent(q),
        headers:{'Content-Type':'application/x-www-form-urlencoded','User-Agent':'CafeFinder/1.0'}
        , signal:AbortSignal.timeout(50000)
      });
      if (r.status===429 || r.status===504) {lastErr=`Лимит или тайм-аут Overpass (${r.status})`;continue;}
      if (!r.ok) {lastErr=`Ошибка Overpass: ${r.status}`;continue;}
      const j = await r.json();
      const items = (j.elements||[]).map(e=>{
        const t=e.tags||{}, lat=e.lat??e.center?.lat, lon=e.lon??e.center?.lon;
        return {
          id:e.type+'/'+e.id, name:t.name, category:classify(t),
          phone:t.phone||t['contact:phone']||t['contact:mobile']||'',
          website:t.website||t['contact:website']||t.url||'',
          city:t['addr:city']||city,
          address:[t['addr:street'],t['addr:housenumber']].filter(Boolean).join(', '),
          lat,lon,source:'OpenStreetMap'
        };
      }).filter(i=>i.name && Number.isFinite(i.lat) && Number.isFinite(i.lon));
      res.setHeader('Cache-Control','s-maxage=600, stale-while-revalidate=300');
      return res.status(200).json({city,items});
    } catch(e) {lastErr='Сеть: '+e.message;}
  }
  return res.status(502).json({error:lastErr});
};