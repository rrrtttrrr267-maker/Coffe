// Vercel Function: GET /api/check?url=https://example.ru
// Проверяет доступность URL, но не подтверждает, что это официальный сайт заведения.
const net = require('node:net');
function isPrivateHost(host) {
  const h=host.toLowerCase().replace(/^\[|\]$/g,'');
  if (h==='localhost' || h.endsWith('.localhost') || h.endsWith('.local')) return true;
  if (net.isIP(h)===4) {
    const p=h.split('.').map(Number);
    return p[0]===0 || p[0]===10 || p[0]===127 || p[0]>=224 ||
      (p[0]===169&&p[1]===254) || (p[0]===172&&p[1]>=16&&p[1]<=31) ||
      (p[0]===192&&p[1]===168);
  }
  if (net.isIP(h)===6) return h==='::1' || h.startsWith('fc') || h.startsWith('fd') || h.startsWith('fe80:');
  return false;
}
function validUrl(value) {
  let u;
  try {u=new URL(value);} catch {return null;}
  if (!['http:','https:'].includes(u.protocol) || !u.hostname || isPrivateHost(u.hostname)) return null;
  return u;
}
module.exports = async (req,res) => {
  if (req.method!=='GET') return res.status(405).json({ok:false,error:'method not allowed'});
  let raw=String(req.query.url||'').trim();
  if (!/^https?:\/\//i.test(raw)) raw='https://'+raw;
  let current=validUrl(raw);
  if (!current) return res.status(400).json({ok:false,error:'invalid or blocked URL'});
  try {
    for (let hop=0;hop<4;hop++) {
      const response=await fetch(current.href,{
        method:'HEAD',redirect:'manual',signal:AbortSignal.timeout(7000),
        headers:{'User-Agent':'Mozilla/5.0 CafeFinder-checker'}
      });
      if ([301,302,303,307,308].includes(response.status)) {
        const location=response.headers.get('location');
        if (!location) return res.status(200).json({ok:false,error:'redirect without location'});
        current=validUrl(new URL(location,current).href);
        if (!current) return res.status(400).json({ok:false,error:'blocked redirect'});
        continue;
      }
      // Некоторые сайты не поддерживают HEAD. Повторяем запросом GET без загрузки тела целиком.
      const ok=response.status<400 || [401,403,405,429].includes(response.status);
      res.setHeader('Cache-Control','s-maxage=3600');
      return res.status(200).json({ok,code:response.status,url:current.href});
    }
    return res.status(200).json({ok:false,error:'too many redirects'});
  } catch(e) {
    return res.status(200).json({ok:false,error:e.name||'network error'});
  }
};